<?php

return [
    'Employees_id'           => '员工表id',
    'Employees_process_wage' => '记件工资',
    'Employees_basis_wage'   => '基本工资',
    'Json'                   => '其他补助',
    'Json key'               => '名称',
    'Json value'             => '值',
    'Total_amount'           => '合计金额[工序单价x工序数量]',
    'Years'                  => '年',
    'Month'                  => '月',
    'Createtime'             => '创建时间',
    'Updatetime'             => '更新时间',
    'Deletetime'             => '删除时间',
    'Employees.code_number'  => '员工编号',
    'Employees.name'         => '名称'
];
