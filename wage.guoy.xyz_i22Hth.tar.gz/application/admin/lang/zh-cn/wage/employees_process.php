<?php

return [
    'Dates'                 => '日期',
    'Employees_id'          => '员工表id',
    'Product_id'            => '产品ID',
    'Process_id'            => '工序表id',
    'Process_price'         => '工序单价',
    'Process_num'           => '工序数量',
    'Total_amount'          => '合计金额[工序单价x工序数量]',
    'Text'                  => '备注',
    'Years'                 => '年',
    'Month'                 => '月',
    'Day'                   => '日',
    'Createtime'            => '创建时间',
    'Updatetime'            => '更新时间',
    'Deletetime'            => '删除时间',
    'Employees.code_number' => '员工编号',
    'Employees.name'        => '名称',
    'Product.name'          => '名称',
    'Process.code_number'   => '工序编号',
    'Process.describe'      => '工序描述'
];
