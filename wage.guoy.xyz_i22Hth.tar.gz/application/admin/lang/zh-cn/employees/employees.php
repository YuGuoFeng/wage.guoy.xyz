<?php

return [
    'Code_number'    => '员工编号',
    'Name'           => '名称',
    'Gender'         => '性别[0:女,1:男]',
    'Age'            => '年龄',
    'Wage'           => '基本工资',
    'Induction_time' => '入职时间',
    'State'          => '状态值',
    'State 0'        => '离职',
    'State 1'        => '在职',
    'Createtime'     => '创建时间',
    'Updatetime'     => '更新时间',
    'Deletetime'     => '删除时间'
];
