<?php

return [
    'Code_number'  => '工序编号',
    'Product_id'   => '产品表id',
    'Describe'     => '工序描述',
    'Price'        => '单价',
    'Createtime'   => '创建时间',
    'Updatetime'   => '更新时间',
    'Deletetime'   => '删除时间',
    'Product.name' => '名称'
];
